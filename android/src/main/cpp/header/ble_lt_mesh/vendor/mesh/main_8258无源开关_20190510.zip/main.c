/********************************************************************************************************
 * @file     main.c 
 *
 * @brief    for TLSR chips
 *
 * @author	 telink
 * @date     Sep. 30, 2010
 *
 * @par      Copyright (c) 2010, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *			 The information contained herein is confidential and proprietary property of Telink 
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this 
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/
#include "proj/tl_common.h"
#include "proj/mcu/watchdog_i.h"
#include "vendor/common/user_config.h"
#include "proj_lib/rf_drv.h"
#include "proj_lib/pm.h"
#include "proj_lib/ble/blt_config.h"
#include "proj_lib/ble/ll/ll.h"

extern void user_init();
extern void main_loop ();

_attribute_ram_code_ void irq_handler(void)
{

}

FLASH_ADDRESS_DEFINE;

_attribute_ram_code_ void cpu_wakeup_init2(void)    //must on ramcode
{
	write_reg8(0x60, 0x00);
	write_reg8(0x61, 0x00);
	write_reg8(0x62, 0x00);
	write_reg8(0x63, 0xff);
	write_reg8(0x64, 0xff);
	write_reg8(0x65, 0xff);

	analog_write(0x82, 0x64); 
	analog_write(0x34, 0x80);
	analog_write(0x0b, 0x38);

	analog_write(0x8c, 0x02); 

	analog_write(0x02, 0xa2);

	analog_write(0x27, 0x00);
	analog_write(0x28, 0x00);
	analog_write(0x29, 0x00);
	analog_write(0x2a, 0x00);

	write_reg32(0xc40, 0x04040404);
	write_reg32(0xc44, 0x04040404);
	write_reg8(0xc48, 0x04);

	write_reg16(0x750, 8000);
    
    if(read_reg8(0x7d) == 0x01){
        analog_write(0x01, 0x3c);
    }else{
        analog_write(0x01, 0x4c);
    }

	{
		REG_ADDR8(0x74f) = BIT(0);    //enable system tick
		extern unsigned int	ota_program_offset;
		extern unsigned int	ota_program_bootAddr;
		ota_program_offset = ota_program_bootAddr;
	}
	
	reg_dma_chn_en = 0;
	reg_dma_chn_irq_msk = 0;
	reg_gpio_wakeup_irq |= (FLD_GPIO_CORE_WAKEUP_EN | FLD_GPIO_CORE_INTERRUPT_EN);
}


extern u8		blc_adv_channel[3];
extern st_ll_adv_t  blta;
extern u8 adv_retry_cnt;
#define			LL_ADV_TX_SETTLE				74
#define				STOP_RF_STATE_MACHINE	( REG_ADDR8(0xf00) = 0x80 )

#define ADV_PAR_LEN_MAX     (sizeof(pkt_adv.data) - 2)  // 
_attribute_ram_code_ void pkt_adv_init(u8 *mac, u8 *par, u32 len)
{
    if(len > ADV_PAR_LEN_MAX){
        len = ADV_PAR_LEN_MAX;
    }
    
	pkt_adv.header.type = LL_TYPE_ADV_NONCONN_IND;
	pkt_adv.data[1] = GAP_ADTYPE_MANUFACTURER_SPECIFIC;
	memcpy(pkt_adv.data + 2,par, len);
	pkt_adv.data[0] = len + 1;
	memcpy(pkt_adv.advA, mac, sizeof(pkt_adv.advA));
	pkt_adv.rf_len = len + 8;
	pkt_adv.dma_len = pkt_adv.rf_len + 2;
}

_attribute_ram_code_ int  blt_send_adv_2(void)
{
    u8 mac[] = {0xe0, 0xe1, 0xe2, 0xe3, 0xe4, 0xe5};
    u8 adv_par[15] = {0};  // ADV_PAR_LEN_MAX
    foreach_arr(i,adv_par){
        adv_par[i] = i + 1;
    }
    pkt_adv_init(mac, adv_par, sizeof(adv_par));

	rf_set_tx_rx_off();//must add
	rf_set_ble_access_code_adv ();
	rf_set_ble_crc_adv ();
	tx_settle_adjust(LL_ADV_TX_SETTLE);   			//suspend ana_34<0> will reset  core_f04
	u8 r = irq_disable();	//replease: reg_rf_irq_mask = 0;	//suspend ana_34<0> will reset  core_f1c

	u32  t_us = (pkt_adv.rf_len + 10) * 8 + 400;

	for (u32 i=0; i<(3*(100+1)); i++)
	{
		u32 chn_idx = i % 3;
		//if (blta.adv_chn_mask & BIT(chn_idx))
		{
			STOP_RF_STATE_MACHINE;						// stop SM
			rf_set_ble_channel (blc_adv_channel[chn_idx]);
			reg_rf_irq_status = FLD_RF_IRQ_TX | FLD_RF_IRQ_RX;
			static u32 A_2;A_2++;
			u32 tx_begin_tick;
			//if((pkt_adv.header.type == LL_TYPE_ADV_NONCONN_IND) || (blta.adv_type == ADV_TYPE_NONCONNECTABLE_UNDIRECTED)){ //ADV_NONCONN_IND
				rf_start_stx ((void *)&pkt_adv, clock_time() + 100);
				tx_begin_tick = clock_time ();
				while (!(reg_rf_irq_status & FLD_RF_IRQ_TX) && (clock_time() - tx_begin_tick) < (t_us - 200)*sys_tick_per_us);
			//}
		}

	}

	irq_restore(r);
	STOP_RF_STATE_MACHINE;
	reg_rf_irq_status = 0xffff;

	return 0;
}


_attribute_ram_code_ int main (void)    //must run in ramcode
{
	FLASH_ADDRESS_CONFIG;
	cpu_wakeup_init2();

	//int deepRetWakeUp = pm_is_MCU_deepRetentionWakeup();  //MCU deep retention wakeUp

	rf_drv_init(RF_MODE_BLE_1M);

	//gpio_init( !deepRetWakeUp );  //analog resistance will keep available in deepSleep mode, so no need initialize again

#if (CLOCK_SYS_CLOCK_HZ == 16000000)
	clock_init(SYS_CLK_16M_Crystal);
#elif (CLOCK_SYS_CLOCK_HZ == 24000000)
	clock_init(SYS_CLK_24M_Crystal);
#endif
	set_tick_per_us (CLOCK_SYS_CLOCK_HZ/1000000);

	rf_set_power_level_index (MY_RF_POWER_INDEX);
	blt_send_adv_2();
	// never RUN to here
    while(1){
        static volatile u32 A_1;A_1++;
    }

    // irq_enable();
}

